//
//  ViewController.swift
//  Experimentation+Combine
//
//  Created by Jullianm on 23/11/2019.
//  Copyright © 2019 Jullianm. All rights reserved.
//

import UIKit
import Combine

class ViewController: UIViewController {
    var viewModel: ViewModel!
    var cancellables = Set<AnyCancellable>()
    var dataSource: TableViewDatasource!
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        viewModel = .init(service: .mockservice())
        dataSource = .init(tableView: tableView)
        
        setupTableView()
        setupBindings()
    }
    
    private func setupTableView() {
        tableView.dataSource = dataSource
        tableView.register(UITableViewCell.self,
                           forCellReuseIdentifier: "Cell")
    }
    
    func setupBindings() {
        viewModel.output.posts
            .assign(to: \.posts, on: dataSource)
            .store(in: &cancellables)
    }
}
