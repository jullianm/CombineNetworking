//
//  ViewModel.swift
//  Experimentation+Combine
//
//  Created by Jullianm on 05/03/2020.
//  Copyright © 2020 Jullianm. All rights reserved.
//

import Combine
import Foundation

protocol ViewModelable: AnyObject {
    func install(service: ServiceManager.ServiceType)
    func handle(result: Result<ServiceConfig.StatusCode, ServiceError>)
}

class ViewModel: ViewModelable {
    struct Output {
        var posts: AnyPublisher<[Post], Never>
    }

    var cancellables = Set<AnyCancellable>()
    let posts = PassthroughSubject<[Post], Never>()
    let output: Output
    
    init(service: ServiceManager.ServiceType) {
        self.output = .init(posts: posts.eraseToAnyPublisher())
        
        install(service: service)
        
        fetch()
        send()
    }
    
    func install(service: ServiceManager.ServiceType) {
        ServiceManager.install(service: service)
        ServiceHandler.shared.install(resultHandler: handle(result:))
    }
    
    func fetch() {
        ServiceManager.posts
            .sink(receiveCompletion: { print($0) },
                  receiveValue: { [weak self] in self?.posts.send($0) })
            .store(in: &cancellables)
    }
    
    func send() {
        ServiceManager.posts = ServiceManager.posts
    }
    
    func handle(result: Result<ServiceConfig.StatusCode, ServiceError>) {
        switch result {
        case .success(let statusCode):
            print("Status code: \(statusCode)")
        case .failure(let error):
            print("Error: \(error)")
        }
    }
}
