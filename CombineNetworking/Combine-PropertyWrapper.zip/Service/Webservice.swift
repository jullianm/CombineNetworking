//
//  Services.swift
//  Experimentation+Combine
//
//  Created by Jullianm on 05/03/2020.
//  Copyright © 2020 Jullianm. All rights reserved.
//

import Combine
import Foundation

protocol Service {
    func fetch<T: Decodable>(endpoint: ServiceConfig.Endpoint<T>, queue: DispatchQueue, method: ServiceConfig.HTTPMethod<T>) -> AnyPublisher<T, ServiceError>
    func send<T: Codable>(endpoint: ServiceConfig.Endpoint<T>, queue: DispatchQueue, method: ServiceConfig.HTTPMethod<T>) -> AnyPublisher<URLResponse, ServiceError>
}

extension URLSession: Service {
    func fetch<T: Decodable>(endpoint: ServiceConfig.Endpoint<T>,
                             queue: DispatchQueue = .main,
                             method: ServiceConfig.HTTPMethod<T> = .get) -> AnyPublisher<T, ServiceError> {
        return self
            .dataTaskPublisher(for: endpoint.urlRequest(method: method))
            .mapError(ServiceError.network)
            .map(\.data)
            .decode(type: endpoint.decodable, decoder: JSONDecoder())
            .mapError(ServiceError.decoding)
            .receive(on: queue)
            .eraseToAnyPublisher()
    }
    
    func send<T: Encodable>(endpoint: ServiceConfig.Endpoint<T>,
                            queue: DispatchQueue = .main,
                            method: ServiceConfig.HTTPMethod<T>) -> AnyPublisher<URLResponse, ServiceError> {
        return self
            .dataTaskPublisher(for: endpoint.urlRequest(method: method))
            .mapError(ServiceError.network)
            .map(\.response)
            .receive(on: queue)
            .eraseToAnyPublisher()
    }
}



